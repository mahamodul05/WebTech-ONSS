<!DOCTYPE html>
<html>
<head>
<style>
	
	
	.footer-dark{
		color: #f0f9ff;
		padding: 15px 0;
		background-color: transparent;
		text-align: center;
        font-family: Tahoma, Geneva, sans-serif;
		font-size: 12px;
		letter-spacing: 0px;
		word-spacing: 1px;
		color: #ffff;
		font-weight: normal;
		text-decoration: none;
		font-style: normal;
		font-variant: normal;
		text-transform: none;

	}
	body{
		size: cover;

	}
	
</style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
</head>

<body>
    <div class="footer-dark">
        <footer>
           <h4>Visit Us</h4>
           <p><b>68 Green Road, Concept tower (3rd Floor) Dhaka: 1205</b></p>
           <h4>Our Services</h4>
           <p>
         		->Nursing Care  ->Baby care ->Elderly care ->Covid-19 Patient care
           </p>
           

           <b>Love yourself, Love your family</b></p>
           
           <p class="copyright">Copyright © 2022 by ONSS</p>
        </footer>
    </div>

    
</body>

</html>




