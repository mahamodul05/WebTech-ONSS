<header>

	<h1 align=center>Online Nursing System.</h1>
	<br>
	<br>
	<div class=nav>

		<a href=admindashboard.php>Homepage</a>
		<a href="adminchangepassword.php">Change Password</a>
		<a href="admineditprofile.php">Update  Profile</a>
		<a href="../Controller/AdminViewProfileAction.php">View  Profile</a>
		<a href="managenurse.php">Manage Nurse</a>
		<a href="managepatient.php">Manage Patient</a>
		<a href="manageacc.php">Manage Accountant</a>
		<a href="adminsearch.php">Search</a>
		<a href="../Controller/AllAdminViewAction.php">View All Admin</a>
		<a href=../Controller/adminlogout.php>Logout</a>
			

	</div>

	<br>
	

	
</header>

