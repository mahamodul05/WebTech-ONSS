<?php

	session_start();

	require('../model/User.php');

	$_SESSION['info'] = getallnurse();

	if(isset($_SESSION['info'])){
		header("Location: ../view/allnurseview.php");
	}














?>