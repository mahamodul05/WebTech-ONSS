<?php 
	require('../Controller/AdminLoginAction.php');
	require('../Controller/header.php');
	include('../Controller/authentication.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin DashBoard</title>
	<link rel="stylesheet" type="text/css" href="CSS/homestyle.css">
</head>
<body>



</body>
</html>

<?php include('../Controller/footer.php')  ?>